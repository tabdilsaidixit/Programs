package Satellite_Control;

import java.util.Random;

import genDevs.*;
import genDevs.modeling.*;
import GenCol.*;
import simView.ViewableAtomic;


public class F3 extends ViewableAtomic{
	double frequencyTime = 16;
	int jobId=0;
	

	String out = "out";
	String wait = "wait";
	String busy = "busy";
	String active = "active";
	double porcT = 30;
	
	

	public F3(){
		this("F3_Write_Format_Alarm_Satellite_Control_Message", 16);
	}

	public F3(String nm, double cpT){
		super(nm);
		frequencyTime = cpT;
		addOutport(out);
	}

	public void initialize(){
		holdIn(active, frequencyTime);
	}

	public void deltext(double e,message x){
		Continue(e);
	}

	public void   deltint(){
		jobId++;
		if (phaseIs(active)){
			double nextMessageTime = frequencyTime;
			holdIn(active, nextMessageTime);
		}
	}

	public message out(){
		message m = new message();
		if (phaseIs(active)){
			MessageSatelliteControl vEnt = new MessageSatelliteControl("AlarmSatelliteControl_"+jobId,porcT, true);
			m.add(makeContent(out, vEnt));
		}
		return m;
	}


}
