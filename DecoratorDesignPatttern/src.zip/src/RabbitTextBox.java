
public class RabbitTextBox implements IVisualComponent {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Rabbit Text Box Draw ==> Draws a TextBox with \"A rabbit\" Text");
	}

}
