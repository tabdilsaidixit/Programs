
public interface IVisualComponent {
	public void draw();
	
	
}
