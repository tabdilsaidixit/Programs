
public class DoubleBorder extends BorderDecorator{

	public DoubleBorder(IVisualComponent decoratedVisualComponent) {
		super(decoratedVisualComponent);
		// TODO Auto-generated constructor stub
	}
	
	
	public void drawBorder() {
		System.out.println("Double Border added");
	}


}
