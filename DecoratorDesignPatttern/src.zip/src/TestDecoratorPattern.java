
public class TestDecoratorPattern {
	public static void main(String[] args) {
		RabbitPictureBox rabbitPictureBox = new RabbitPictureBox();
		IVisualComponent rabbitPictureBoxWithDecorator = new  HeaderBar(new SolidBorder(rabbitPictureBox));
//		rabbitPictureBoxWithDecorator.draw();
//		
//		System.out.println(" -------------------  ");
//		
		EmptyTextBox emptyTextBox = new EmptyTextBox();
		IVisualComponent emptyTextBoxWithDecorator = new SolidBorder (new HeaderBar(emptyTextBox));
//		emptyTextBoxWithDecorator.draw();
//		
//		
//		System.out.println(" -------------------  ");
//		
		RabbitTextBox rabbitTextBox = new RabbitTextBox();
		IVisualComponent rabbitTextBoxWithDecorator = new SolidBorder(rabbitTextBox);
//		rabbitTextBoxWithDecorator.draw();
//		
		
		ComponentsContainer componentsContainer1 = new ComponentsContainer();
		componentsContainer1.addComponent(rabbitPictureBoxWithDecorator);

		componentsContainer1.addComponent(rabbitTextBoxWithDecorator);
		
		ComponentsContainer mainComponentsContainer = new ComponentsContainer();
		mainComponentsContainer.addComponent(componentsContainer1);
		
		mainComponentsContainer.addComponent(emptyTextBoxWithDecorator);
		IVisualComponent mainComponent = new HeaderBar(new SolidBorder(mainComponentsContainer));
		
		mainComponentsContainer.draw();
		
	}
}
