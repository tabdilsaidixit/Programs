
public class RabbitPictureBox implements IVisualComponent {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Rabbit Picture Box Draw ==> Draws a Rabbit Picture");
	}

}
