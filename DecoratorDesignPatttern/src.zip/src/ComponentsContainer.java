
import java.util.ArrayList;
import java.util.List;

class ComponentsContainer implements IVisualComponent
{ 
	private List<IVisualComponent> componentsList = new ArrayList<IVisualComponent>(); 
	
		
	public void addComponent(IVisualComponent component) 
	{ 
		componentsList.add(component); 
	} 
		
	public void removeComponent(IVisualComponent component) 
	{ 
		componentsList.remove(component); 
	}

	@Override
	public void draw() {
		
		System.out.println("Component Container draw ===> Draws all components in container");
		// TODO Auto-generated method stub
		for(IVisualComponent component:componentsList) 
		{ 
			component.draw(); 
		} 
	} 
} 