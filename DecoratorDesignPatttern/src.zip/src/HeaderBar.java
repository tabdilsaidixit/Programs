
public class HeaderBar extends Decorator {

	public HeaderBar(IVisualComponent decoratedVisualComponent) {
		super(decoratedVisualComponent);
		// TODO Auto-generated constructor stub
	}
	public void draw() {
		super.draw();
		drawBorder();
		
	}
	public void drawBorder() {
		System.out.println("Header Bar added");
	}

}
