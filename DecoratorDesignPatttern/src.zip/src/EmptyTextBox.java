
public class EmptyTextBox implements IVisualComponent {

	@Override
	public void draw() {
		// TODO Auto-generated method stub
		System.out.println("Empty Text Box Draw ==> Draws an Empty Text Box ");
	}

}
